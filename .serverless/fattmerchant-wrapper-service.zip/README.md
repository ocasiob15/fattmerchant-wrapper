# fattmerchant-wrapper
A microservice that wraps around fattmerchants platform
